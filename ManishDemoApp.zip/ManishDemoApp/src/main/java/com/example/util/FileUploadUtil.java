package com.example.util;

import org.springframework.stereotype.Component;

import com.example.model.FileUpload;

@Component
public class FileUploadUtil {

	public void mapToActualObject(FileUpload actual, FileUpload fileUpload) {
		if(fileUpload.getName()!=null)
			actual.setName(fileUpload.getName());
		actual.setGender(fileUpload.getGender());
		
		if(fileUpload.getEmail()!=null)
			actual.setEmail(fileUpload.getEmail());
		actual.setFile(fileUpload.getFile());
		
	}

}
