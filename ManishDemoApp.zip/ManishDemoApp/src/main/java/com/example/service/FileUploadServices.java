package com.example.service;

import java.util.List;
import java.util.Optional;

import com.example.model.FileUpload;

public interface FileUploadServices {
	
	Integer saveFileUpload(FileUpload s);
	void updateFileUpload(FileUpload s);
	
	void deleteFileUpload(Integer id);
	
	Optional<FileUpload> getOneFileUpload(Integer id);
	List<FileUpload> getAllFileUploads();
	
	boolean isFileUploadExist(Integer id);
}
