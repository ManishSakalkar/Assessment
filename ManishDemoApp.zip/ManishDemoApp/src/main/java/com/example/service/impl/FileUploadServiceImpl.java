package com.example.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.model.FileUpload;
import com.example.repo.FileUploadRepository;
import com.example.service.FileUploadServices;

@Service
public class FileUploadServiceImpl implements FileUploadServices {
	@Autowired
	private FileUploadRepository repo;
	
	@Override
	public Integer saveFileUpload(FileUpload s) {
		s = repo.save(s);
		return s.getId();
	}

	@Override
	public void updateFileUpload(FileUpload s) {
		repo.save(s);
	}

	@Override
	public void deleteFileUpload(Integer id) {
		repo.deleteById(id);
	}

	@Override
	public Optional<FileUpload> getOneFileUpload(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<FileUpload> getAllFileUploads() {
		return repo.findAll();
	}

	@Override
	public boolean isFileUploadExist(Integer id) {
		return repo.existsById(id);
	}

}
